

BOOL IsWinNT(void);
BOOL IsPossibleWriteHklmRun(void);
